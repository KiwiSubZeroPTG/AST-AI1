/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["sjc.microlink.io"],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
}

module.exports = nextConfig

