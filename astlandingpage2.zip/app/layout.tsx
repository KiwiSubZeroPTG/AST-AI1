import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import Logo from "@/components/Logo"
import Link from "next/link"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AST - Advanced Solutions Technology",
  description: "Cutting-edge tools for AI, scripting, exploit development, and game creation.",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-black text-white min-h-screen flex flex-col`}>
        <header className="border-b border-white/10 bg-black/80 backdrop-blur-md sticky top-0 z-50">
          <div className="container mx-auto flex h-16 items-center px-4">
            <Link href="/home" className="flex items-center gap-2">
              <Logo className="w-8 h-8" />
              <span className="text-2xl font-bold tracking-tighter text-white [text-shadow:_0_0_10px_rgba(255,255,255,0.5)]">
                AST
              </span>
            </Link>
            <nav className="ml-auto flex items-center gap-6">
              <Link href="/features" className="text-sm font-medium text-white/70 transition-colors hover:text-white">
                Features
              </Link>
              <Link href="/pricing" className="text-sm font-medium text-white/70 transition-colors hover:text-white">
                Pricing
              </Link>
              <Link href="/about" className="text-sm font-medium text-white/70 transition-colors hover:text-white">
                About
              </Link>
              <Link href="/chat" className="text-sm font-medium text-white/70 transition-colors hover:text-white">
                Chat
              </Link>
            </nav>
          </div>
        </header>
        <main className="flex-grow">{children}</main>
        <footer className="border-t border-white/10 bg-black py-8">
          <div className="container mx-auto px-4 text-center text-sm text-white/50">
            <p>© {new Date().getFullYear()} AST. All rights reserved.</p>
          </div>
        </footer>
      </body>
    </html>
  )
}

import "./globals.css"



import './globals.css'