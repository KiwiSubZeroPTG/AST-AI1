import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  const team = [
    {
      name: "Asher",
      role: "Lead AI Developer",
      bio: "Specializes in artificial intelligence and machine learning algorithms with over 5 years of experience in developing cutting-edge AI solutions.",
      image:
        "https://sjc.microlink.io/j6bN2H36cU7k3kzL08aeBGY1U5KLP0Vl7_cE2MaNuEe5cYdlxkV6uGyTXCNvYqVYb60b0QWzaKBhd2NzkUsDBw.jpeg",
    },
    {
      name: "Louis",
      role: "Script Engineer",
      bio: "Expert in scripting languages and automation with a background in developing efficient and scalable solutions for complex problems.",
      image:
        "https://sjc.microlink.io/2lIuyr_mUGDa_EatoW79iK0Ifn0AtGYLVzn0vQPMr8-9sLk_-GubZj1mcBqcEVg_oTbV76RSMZsuNos_Oxfdyg.jpeg",
    },
    {
      name: "Chun",
      role: "Security Specialist",
      bio: "Cybersecurity expert with extensive experience in vulnerability assessment, penetration testing, and secure application development.",
      image:
        "https://sjc.microlink.io/wW77E75iF8h6JrMRV10KJbnNb3ULTlge5fT4WLpqpPNkN-4sf-Hx5Pr-zCqlY5C7zedUewHkKce_YAGK9by9Qg.jpeg",
    },
    {
      name: "Sky",
      role: "Game Development Lead",
      bio: "Creative game developer with a passion for creating immersive experiences and innovative gameplay mechanics.",
      image: "/placeholder.svg?height=400&width=400",
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black/80 backdrop-blur-md">
        <div className="container flex h-16 items-center px-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold tracking-tighter text-white [text-shadow:_0_0_10px_rgba(255,255,255,0.5)]">
              AST
            </span>
          </Link>
          <nav className="ml-auto flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-white/70 transition-colors hover:text-white">
              Home
            </Link>
          </nav>
        </div>
      </header>

      <main className="container px-4 py-16">
        <div className="mx-auto max-w-6xl">
          <h1 className="mb-6 text-4xl font-bold tracking-tight [text-shadow:_0_0_15px_rgba(255,255,255,0.5)]">
            About AST
          </h1>

          <div className="mb-12">
            <p className="mb-4 text-lg text-white/80">
              Advanced Solutions Technology (AST) is a cutting-edge technology company specializing in AI, scripting,
              security, and game development tools. Founded with a vision to empower developers and creators with
              professional-grade solutions, AST has quickly become a leader in the industry.
            </p>
            <p className="mb-4 text-lg text-white/80">
              Our mission is to provide innovative tools that simplify complex processes and enable our users to focus
              on what matters most - creating amazing products and experiences.
            </p>
            <p className="text-lg text-white/80">
              With a team of experienced developers and industry experts, we're committed to delivering high-quality
              solutions that meet the evolving needs of our users.
            </p>
          </div>

          <h2 className="mb-6 text-3xl font-bold tracking-tight">Our Team</h2>

          <div className="mb-12 grid gap-8 md:grid-cols-2">
            {team.map((member, index) => (
              <div
                key={index}
                className="flex flex-col gap-6 rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10"
              >
                <div className="flex-shrink-0">
                  <Image
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    width={300}
                    height={300}
                    className="rounded-lg object-cover w-full h-[300px]"
                  />
                </div>
                <div>
                  <h3 className="mb-1 text-2xl font-medium">{member.name}</h3>
                  <p className="mb-2 text-sm text-white/70">{member.role}</p>
                  <p className="text-sm text-white/80">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-lg border border-white/10 bg-white/5 p-8">
            <h2 className="mb-4 text-2xl font-bold">Join the AST Community</h2>
            <p className="mb-6 text-white/80">
              Connect with other developers, share your projects, and get support from our team.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-white text-black hover:bg-white/90">Join Discord</Button>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 hover:text-white">
                Follow on Twitter
              </Button>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-white/10 bg-black py-8">
        <div className="container px-4 text-center text-sm text-white/50">
          <p>© {new Date().getFullYear()} AST. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

