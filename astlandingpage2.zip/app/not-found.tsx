import Link from "next/link"
import { Button } from "@/components/ui/button"
import Logo from "@/components/Logo"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8 text-center">
        <Logo className="mx-auto w-16 h-16 mb-4" />
        <h1 className="text-4xl font-bold mb-4">404 - Page Not Found</h1>
        <p className="text-xl mb-8">Oops! The page you're looking for doesn't exist.</p>
        <p className="text-gray-400 mb-8">
          It seems you've followed a broken link or entered a URL that doesn't exist on this site.
        </p>
        <Link href="/">
          <Button className="bg-white text-black hover:bg-white/90">Go back to homepage</Button>
        </Link>
      </div>
    </div>
  )
}

