import { type NextRequest, NextResponse } from "next/server"

const OWNER_USER_ID = "1759864847"

async function checkPurchaseStatus(userId: string): Promise<boolean> {
  // Check if the user is the owner
  if (userId === OWNER_USER_ID) {
    return true
  }

  // For other users, check if they have purchased (you would implement your actual check here)
  // This is a mock implementation
  await new Promise((resolve) => setTimeout(resolve, 1000))
  return Number.parseInt(userId) % 2 === 0
}

export async function GET(request: NextRequest) {
  const userId = request.nextUrl.searchParams.get("userId")

  if (!userId) {
    return NextResponse.json({ error: "User ID is required" }, { status: 400 })
  }

  try {
    const hasPurchased = await checkPurchaseStatus(userId)
    return NextResponse.json({ hasPurchased })
  } catch (error) {
    console.error("Error checking purchase status:", error)
    return NextResponse.json({ error: "Failed to check purchase status" }, { status: 500 })
  }
}

