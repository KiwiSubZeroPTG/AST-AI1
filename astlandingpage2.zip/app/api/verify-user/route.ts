import { type NextRequest, NextResponse } from "next/server"

const OWNER_USER_ID = "1759864847"

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json(
        {
          error: "User ID is required",
        },
        { status: 400 },
      )
    }

    // Simple verification logic
    const hasPurchased = userId === OWNER_USER_ID || Number(userId) % 2 === 0

    return NextResponse.json({
      hasPurchased,
      verified: true,
    })
  } catch (error) {
    return NextResponse.json(
      {
        error: "Failed to verify user",
      },
      { status: 500 },
    )
  }
}

