"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Loader2 } from "lucide-react"
import { sendChatMessage } from "@/app/actions"
import { getCredits, useCredit, checkAndResetCredits, getRemainingTime } from "@/app/utils/credits"

export default function ChatPage() {
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([
    { role: "system", content: "Welcome to AST Chat!" },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [credits, setCredits] = useState(getCredits())
  const [timeUntilReset, setTimeUntilReset] = useState(getRemainingTime())
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const router = useRouter()
  const [hasCredits, setHasCredits] = useState(true)

  useEffect(() => {
    // Check and reset credits every minute
    const interval = setInterval(() => {
      checkAndResetCredits()
      setCredits(getCredits())
      setTimeUntilReset(getRemainingTime())
    }, 60000)

    return () => clearInterval(interval)
  }, [])

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [scrollToBottom])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    // Check if user has credits or is pro
    const hasPurchased = localStorage.getItem("hasPurchased") === "true"
    let canUseCredit = true
    if (!hasPurchased) {
      canUseCredit = useCredit()
      setHasCredits(canUseCredit)
    }

    if (!hasPurchased && !canUseCredit) {
      setMessages((prev) => [
        ...prev,
        {
          role: "system",
          content: "You've used all your credits. Please wait for the reset or upgrade to Pro for unlimited access.",
        },
      ])
      return
    }

    const userMessage = { role: "user", content: input }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await sendChatMessage(input)
      setMessages((prev) => [...prev, { role: "assistant", content: response }])
    } catch (error) {
      console.error("Error sending message:", error)
      setMessages((prev) => [
        ...prev,
        {
          role: "system",
          content: "Sorry, there was an error processing your message. Please try again.",
        },
      ])
    } finally {
      setIsLoading(false)
      setCredits(getCredits()) // Update credits display
    }
  }

  const handleUpgrade = () => {
    router.push("/purchase")
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex-1 container px-4 py-8 flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-3xl font-bold [text-shadow:_0_0_15px_rgba(255,255,255,0.5)]">AST Chat</h1>
          {localStorage.getItem("hasPurchased") !== "true" && (
            <div className="text-sm text-white/70">
              Credits: {credits} | Reset in: {timeUntilReset}
            </div>
          )}
        </div>

        <div className="flex-1 flex flex-col">
          <div className="flex-1 border border-white/10 rounded-t-md bg-white/5 p-4 overflow-y-auto max-h-[500px]">
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-lg px-4 py-2 ${
                      message.role === "user"
                        ? "bg-white/10 text-white"
                        : message.role === "system"
                          ? "bg-white/5 text-white/70 border border-white/10"
                          : "bg-white text-black"
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </div>

          <form
            onSubmit={handleSendMessage}
            className="flex gap-2 p-4 border border-t-0 border-white/10 rounded-b-md bg-white/5"
          >
            <Input
              type="text"
              placeholder="Type your message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={isLoading}
              className="bg-black/50 border-white/10 text-white"
            />
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-white text-black hover:bg-white/90"
            >
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </form>
        </div>

        {credits === 0 && localStorage.getItem("hasPurchased") !== "true" && (
          <div className="mt-4 p-4 border border-white/10 rounded-md bg-white/5">
            <p className="text-center mb-4">You've used all your free credits. Upgrade to Pro for unlimited access!</p>
            <Button onClick={handleUpgrade} className="w-full bg-white text-black hover:bg-white/90">
              Upgrade to Pro
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

