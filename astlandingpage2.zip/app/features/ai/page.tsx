import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function AIFeaturePage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black/80 backdrop-blur-md">
        <div className="container flex h-16 items-center px-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold tracking-tighter text-white [text-shadow:_0_0_10px_rgba(255,255,255,0.5)]">
              AST
            </span>
          </Link>
          <nav className="ml-auto flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-white/70 transition-colors hover:text-white">
              Home
            </Link>
          </nav>
        </div>
      </header>

      <main className="container px-4 py-16">
        <div className="mx-auto max-w-4xl">
          <h1 className="mb-6 text-4xl font-bold tracking-tight [text-shadow:_0_0_15px_rgba(255,255,255,0.5)]">
            Advanced AI Solutions
          </h1>

          <div className="mb-12 grid gap-8 md:grid-cols-2">
            <div>
              <p className="mb-4 text-lg text-white/80">
                Our cutting-edge AI technology provides intelligent solutions for complex problems. With
                state-of-the-art algorithms and machine learning capabilities, AST's AI can transform your workflow and
                automate critical processes.
              </p>
              <p className="mb-6 text-lg text-white/80">
                From natural language processing to predictive analytics, our AI tools are designed to give you a
                competitive edge in today's technology landscape.
              </p>
              <Button className="bg-white text-black hover:bg-white/90">Try AI Features</Button>
            </div>
            <div className="relative rounded-lg border border-white/10 bg-white/5 p-1 [box-shadow:0_0_20px_rgba(255,255,255,0.1)]">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="AI Technology Visualization"
                width={600}
                height={400}
                className="rounded-lg"
              />
            </div>
          </div>

          <h2 className="mb-6 text-2xl font-bold">Key AI Features</h2>

          <div className="mb-12 grid gap-6 md:grid-cols-3">
            <div className="rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10">
              <h3 className="mb-3 text-xl font-medium">Natural Language Processing</h3>
              <p className="text-sm text-white/70">
                Advanced text analysis and understanding capabilities for processing human language and extracting
                meaningful insights.
              </p>
            </div>
            <div className="rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10">
              <h3 className="mb-3 text-xl font-medium">Machine Learning</h3>
              <p className="text-sm text-white/70">
                Sophisticated algorithms that learn from data patterns to make predictions and automate decision-making
                processes.
              </p>
            </div>
            <div className="rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10">
              <h3 className="mb-3 text-xl font-medium">Computer Vision</h3>
              <p className="text-sm text-white/70">
                Image and video analysis technology that can identify objects, people, and activities with remarkable
                accuracy.
              </p>
            </div>
          </div>

          <div className="rounded-lg border border-white/10 bg-white/5 p-8">
            <h2 className="mb-4 text-2xl font-bold">Ready to experience the power of AST AI?</h2>
            <p className="mb-6 text-white/80">
              Unlock the full potential of our AI tools with a Pro subscription. Get access to exclusive features and
              priority support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-white text-black hover:bg-white/90">Upgrade to Pro</Button>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 hover:text-white">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-white/10 bg-black py-8">
        <div className="container px-4 text-center text-sm text-white/50">
          <p>© {new Date().getFullYear()} AST. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

