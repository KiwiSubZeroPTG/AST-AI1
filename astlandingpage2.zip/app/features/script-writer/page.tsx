import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function ScriptWriterPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black/80 backdrop-blur-md">
        <div className="container flex h-16 items-center px-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold tracking-tighter text-white [text-shadow:_0_0_10px_rgba(255,255,255,0.5)]">
              AST
            </span>
          </Link>
          <nav className="ml-auto flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-white/70 transition-colors hover:text-white">
              Home
            </Link>
          </nav>
        </div>
      </header>

      <main className="container px-4 py-16">
        <div className="mx-auto max-w-4xl">
          <h1 className="mb-6 text-4xl font-bold tracking-tight [text-shadow:_0_0_15px_rgba(255,255,255,0.5)]">
            Professional Script Writer
          </h1>

          <div className="mb-12 grid gap-8 md:grid-cols-2">
            <div>
              <p className="mb-4 text-lg text-white/80">
                Create powerful, efficient scripts for any platform with our advanced script writing tools. Whether
                you're developing automation scripts, game mechanics, or system utilities, AST's Script Writer provides
                the environment and tools you need.
              </p>
              <p className="mb-6 text-lg text-white/80">
                With syntax highlighting, intelligent code completion, and a vast library of templates, you can
                accelerate your development process and focus on creating innovative solutions.
              </p>
              <Button className="bg-white text-black hover:bg-white/90">Try Script Writer</Button>
            </div>
            <div className="relative rounded-lg border border-white/10 bg-white/5 p-1 [box-shadow:0_0_20px_rgba(255,255,255,0.1)]">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Script Writer Interface"
                width={600}
                height={400}
                className="rounded-lg"
              />
            </div>
          </div>

          <h2 className="mb-6 text-2xl font-bold">Key Features</h2>

          <div className="mb-12 grid gap-6 md:grid-cols-3">
            <div className="rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10">
              <h3 className="mb-3 text-xl font-medium">Intelligent Code Completion</h3>
              <p className="text-sm text-white/70">
                Smart suggestions that understand your code context and help you write faster with fewer errors.
              </p>
            </div>
            <div className="rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10">
              <h3 className="mb-3 text-xl font-medium">Template Library</h3>
              <p className="text-sm text-white/70">
                Access hundreds of pre-built script templates to jumpstart your development process.
              </p>
            </div>
            <div className="rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10">
              <h3 className="mb-3 text-xl font-medium">Cross-Platform Support</h3>
              <p className="text-sm text-white/70">
                Write scripts that work seamlessly across multiple platforms and environments.
              </p>
            </div>
          </div>

          <div className="rounded-lg border border-white/10 bg-white/5 p-8">
            <h2 className="mb-4 text-2xl font-bold">Ready to elevate your scripting capabilities?</h2>
            <p className="mb-6 text-white/80">
              Unlock the full potential of our Script Writer with a Pro subscription. Get access to exclusive templates
              and priority support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-white text-black hover:bg-white/90">Upgrade to Pro</Button>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 hover:text-white">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-white/10 bg-black py-8">
        <div className="container px-4 text-center text-sm text-white/50">
          <p>© {new Date().getFullYear()} AST. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

