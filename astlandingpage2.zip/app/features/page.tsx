import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Code, Shield, Gamepad } from "lucide-react"

export default function FeaturesPage() {
  const features = [
    {
      title: "Advanced AI",
      description: "State-of-the-art artificial intelligence solutions for complex problem-solving and automation.",
      icon: <ArrowRight className="w-10 h-10" />,
      link: "/features/ai",
    },
    {
      title: "Script Writer",
      description: "Professional scripting tools to create efficient, powerful code for any platform.",
      icon: <Code className="w-10 h-10" />,
      link: "/features/script-writer",
    },
    {
      title: "Exploit Developer",
      description: "Secure testing and development tools for identifying and addressing vulnerabilities.",
      icon: <Shield className="w-10 h-10" />,
      link: "/features/exploit-developer",
    },
    {
      title: "Game Developer",
      description: "Comprehensive game development suite for creating immersive gaming experiences.",
      icon: <Gamepad className="w-10 h-10" />,
      link: "/features/game-developer",
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8 text-center [text-shadow:_0_0_15px_rgba(255,255,255,0.5)]">
          AST Features
        </h1>
        <div className="grid gap-8 md:grid-cols-2">
          {features.map((feature, index) => (
            <Link
              href={feature.link}
              key={index}
              className="group relative overflow-hidden rounded-lg border border-white/10 bg-white/5 p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/10 hover:[transform:translateY(-5px)] hover:[box-shadow:0_0_20px_rgba(255,255,255,0.2)]"
            >
              <div className="mb-4 text-white/70 group-hover:text-white transition-colors">{feature.icon}</div>
              <h2 className="text-2xl font-bold mb-2">{feature.title}</h2>
              <p className="text-white/70 mb-4">{feature.description}</p>
              <Button variant="outline" className="group-hover:bg-white group-hover:text-black transition-colors">
                Learn More
              </Button>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}

