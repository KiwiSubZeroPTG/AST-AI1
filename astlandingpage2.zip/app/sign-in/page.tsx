"use client"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { checkAndResetCredits } from "@/app/utils/credits"

export default function SignInPage() {
  const router = useRouter()

  const handleFreeAccess = () => {
    localStorage.setItem("hasPurchased", "false")
    checkAndResetCredits() // Initialize credits for new user
    router.push("/chat")
  }

  const handleProAccess = () => {
    router.push("/purchase")
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold">Welcome to AST Chat</h2>
          <p className="mt-2 text-sm text-gray-400">Choose how you want to access the chat</p>
        </div>

        <div className="space-y-4">
          <Button onClick={handleFreeAccess} className="w-full bg-white/10 text-white hover:bg-white/20">
            Start Free (50 credits every 12 hours)
          </Button>

          <Button onClick={handleProAccess} className="w-full bg-white text-black hover:bg-white/90">
            Get Pro (Unlimited Access)
          </Button>
        </div>
      </div>
    </div>
  )
}

