const CREDITS_KEY = "chat_credits"
const LAST_RESET_KEY = "last_credits_reset"
const FREE_CREDITS = 50
const RESET_INTERVAL = 12 * 60 * 60 * 1000 // 12 hours in milliseconds

export function getCredits(): number {
  const credits = localStorage.getItem(CREDITS_KEY)
  return credits ? Number.parseInt(credits) : FREE_CREDITS
}

export function useCredit(): boolean {
  const currentCredits = getCredits()
  if (currentCredits > 0) {
    localStorage.setItem(CREDITS_KEY, (currentCredits - 1).toString())
    return true
  }
  return false
}

export function checkAndResetCredits(): void {
  const lastReset = localStorage.getItem(LAST_RESET_KEY)
  const now = Date.now()

  if (!lastReset || now - Number.parseInt(lastReset) >= RESET_INTERVAL) {
    localStorage.setItem(CREDITS_KEY, FREE_CREDITS.toString())
    localStorage.setItem(LAST_RESET_KEY, now.toString())
  }
}

export function getRemainingTime(): string {
  const lastReset = localStorage.getItem(LAST_RESET_KEY)
  if (!lastReset) return "0h 0m"

  const now = Date.now()
  const timeSinceReset = now - Number.parseInt(lastReset)
  const timeUntilReset = RESET_INTERVAL - timeSinceReset

  if (timeUntilReset <= 0) return "0h 0m"

  const hours = Math.floor(timeUntilReset / (60 * 60 * 1000))
  const minutes = Math.floor((timeUntilReset % (60 * 60 * 1000)) / (60 * 1000))
  return `${hours}h ${minutes}m`
}

