import { Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function PricingPage() {
  const plans = [
    {
      name: "Free",
      price: "R$0",
      description: "Basic access for beginners",
      features: [
        { name: "Basic AI assistance", included: true },
        { name: "Limited script templates", included: true },
        { name: "Community support", included: true },
        { name: "Chat access", included: false },
        { name: "Advanced features", included: false },
        { name: "Priority support", included: false },
      ],
      button: "Get Started",
      popular: false,
    },
    {
      name: "Pro",
      price: "R$350",
      description: "Full access for professionals",
      features: [
        { name: "Advanced AI capabilities", included: true },
        { name: "Full script library access", included: true },
        { name: "Priority support", included: true },
        { name: "Exclusive chat access", included: true },
        { name: "Custom solutions", included: true },
        { name: "API access", included: false },
      ],
      button: "Upgrade Now",
      popular: true,
      gamePassUrl: "https://www.roblox.com/game-pass/1084197017/350",
    },
    {
      name: "Exclusive",
      price: "R$750",
      description: "Ultimate access for power users",
      features: [
        { name: "Advanced AI capabilities", included: true },
        { name: "Full script library access", included: true },
        { name: "24/7 Priority support", included: true },
        { name: "Exclusive chat access", included: true },
        { name: "Custom solutions", included: true },
        { name: "API access", included: true },
      ],
      button: "Go Exclusive",
      popular: false,
      gamePassUrl: "https://www.roblox.com/game-pass/1084019809/IMG-0118-png",
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white py-16">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h1 className="mb-4 text-4xl font-bold tracking-tight [text-shadow:_0_0_15px_rgba(255,255,255,0.5)]">
            Choose Your Plan
          </h1>
          <p className="mx-auto max-w-2xl text-lg text-white/70">
            Unlock the full potential of AST with our premium plans.
          </p>
        </div>
        <div className="grid gap-8 md:grid-cols-3">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative overflow-hidden rounded-lg border ${
                plan.popular
                  ? "border-white/20 bg-white/10 [box-shadow:0_0_20px_rgba(255,255,255,0.1)]"
                  : "border-white/10 bg-white/5"
              } p-8 transition-all duration-300 hover:border-white/30 hover:bg-white/15`}
            >
              {plan.popular && (
                <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-3xl"></div>
              )}
              {plan.popular && (
                <div className="mb-4 inline-block rounded-full bg-white px-3 py-1 text-xs font-semibold text-black">
                  RECOMMENDED
                </div>
              )}
              <div className="mb-6 relative">
                <h3 className="mb-2 text-2xl font-bold">{plan.name}</h3>
                <p className="text-white/70">{plan.description}</p>
                <div className="mt-4 flex items-baseline">
                  <span className="text-4xl font-bold">{plan.price}</span>
                </div>
              </div>
              <ul className="mb-8 space-y-4 text-sm relative">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    {feature.included ? (
                      <Check className="mr-2 h-5 w-5 text-green-400" />
                    ) : (
                      <X className="mr-2 h-5 w-5 text-white/30" />
                    )}
                    <span className={feature.included ? "" : "text-white/50"}>{feature.name}</span>
                  </li>
                ))}
              </ul>
              {plan.gamePassUrl ? (
                <a href={plan.gamePassUrl} target="_blank" rel="noopener noreferrer">
                  <Button
                    className={`w-full ${
                      plan.popular
                        ? "bg-white text-black hover:bg-white/90"
                        : "border-white/20 bg-transparent text-white hover:bg-white/10"
                    }`}
                  >
                    {plan.button}
                  </Button>
                </a>
              ) : (
                <Button
                  className={`w-full ${
                    plan.popular
                      ? "bg-white text-black hover:bg-white/90"
                      : "border-white/20 bg-transparent text-white hover:bg-white/10"
                  }`}
                >
                  {plan.button}
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

