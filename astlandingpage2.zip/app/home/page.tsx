"use client"

import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Logo from "@/components/Logo"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <main className="flex-grow container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <Logo className="mx-auto w-24 h-24 mb-8" />
          <h1 className="text-5xl font-bold mb-6 [text-shadow:_0_0_15px_rgba(255,255,255,0.5)]">
            Advanced Solutions Technology
          </h1>
          <p className="text-xl text-gray-400 mb-8">
            Cutting-edge tools for AI, scripting, exploit development, and game creation
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/sign-in">
              <Button className="bg-white text-black hover:bg-white/90 text-lg px-8 py-4">Get Started</Button>
            </Link>
            <Link href="/features">
              <Button
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 hover:text-white text-lg px-8 py-4"
              >
                Explore Features
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {["AI", "Scripting", "Security", "Game Dev"].map((feature, index) => (
            <div
              key={index}
              className="bg-white/5 border border-white/10 rounded-lg p-6 hover:bg-white/10 transition-colors"
            >
              <h3 className="text-xl font-semibold mb-4">{feature}</h3>
              <p className="text-gray-400 mb-4">
                Advanced tools and solutions for {feature.toLowerCase()} professionals.
              </p>
              <Link
                href={`/features#${feature.toLowerCase().replace(" ", "-")}`}
                className="text-white hover:underline inline-flex items-center"
              >
                Learn more <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
          ))}
        </div>
      </main>

      <footer className="border-t border-white/10 py-8">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} AST. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

