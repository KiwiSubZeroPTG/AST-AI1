"use server"

import { CohereClient } from "cohere-ai"

const cohere = new CohereClient({
  token: process.env.COHERE_API_KEY || "",
})

export async function sendChatMessage(message: string) {
  if (!process.env.COHERE_API_KEY) {
    console.error("COHERE_API_KEY is not set")
    throw new Error("API key not configured")
  }

  try {
    const response = await cohere.chat({
      model: "command-r-plus",
      message: message,
      temperature: 0.3,
      max_tokens: 300,
    })

    return response.text
  } catch (error) {
    console.error("Error in sendChatMessage:", error)
    throw new Error("Failed to send message")
  }
}

