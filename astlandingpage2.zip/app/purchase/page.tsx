"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import Logo from "@/components/Logo"

export default function PurchasePage() {
  const [userId, setUserId] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    const storedUserId = localStorage.getItem("userId")
    if (!storedUserId) {
      router.push("/sign-in")
    } else {
      setUserId(storedUserId)
    }
  }, [router])

  const handlePurchase = () => {
    // Redirect to Roblox game pass purchase page
    window.location.href = "https://www.roblox.com/game-pass/1084197017/350"
  }

  if (!userId) {
    return null // or a loading spinner
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <Logo className="mx-auto w-16 h-16 mb-4" />
          <h2 className="mt-6 text-3xl font-extrabold">Purchase Premium Access</h2>
          <p className="mt-2 text-sm text-gray-400">Unlock all features of AST Premium Chat</p>
        </div>
        <div className="mt-8 space-y-6">
          <div className="bg-white/5 border border-white/10 rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4">Premium Package</h3>
            <ul className="list-disc list-inside mb-4 text-gray-300">
              <li>Unlimited access to AI chat</li>
              <li>Advanced scripting tools</li>
              <li>Priority support</li>
              <li>Early access to new features</li>
            </ul>
            <p className="text-2xl font-bold mb-6">350 Robux</p>
            <Button onClick={handlePurchase} className="w-full bg-white text-black hover:bg-white/90">
              Purchase Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

